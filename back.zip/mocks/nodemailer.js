//mocks/nodemailer.js
const nodemailerMock = require('nodemailer-mock');
module.exports = nodemailerMock;

